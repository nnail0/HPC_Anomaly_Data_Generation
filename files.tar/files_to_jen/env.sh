conda activate ldms_old
export LD_LIBRARY_PATH=/home/nathaniel-filer/ldms/ldms:$LD_LIBRARY_PATH
# /home/nathaniel-filer/miniconda3/envs/ldms_old/bin/python3.8
#export SUBSCRIBER_DATA=/home/nathaniel-filer/papi.json
SUBSCRIBER_DATA='{"papi_sampler":{"file":"/home/nathaniel-filer/papi.json"}}'
